#directory "../MLGRAPH.DIR";;

#open "MLgraph";;
load_object "MLgraph";;

load_object "permutations";;
#open "permutations";;

load_object "complex";;
#open "complex";;

load_object "pavages1";;
#open "pavages1";;

load_object"pavages2";;
#open "pavages2";;

