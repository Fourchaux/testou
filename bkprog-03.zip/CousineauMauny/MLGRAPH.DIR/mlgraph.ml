load_object"MLgraph";;
#open "MLgraph";;

(*
directory_concat_string:= "/";;
change_graphics_directory "/usr/local/lib/caml-light";;
*)
