
#open "MLgraph";;

(* Pour Unix *)
directory_concat_string:="/";;
change_graphics_directory "./packagedir";;
