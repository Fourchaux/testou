#directory "../Util";;
#directory "../Termes";;
#directory "../Compil";;

load_object "ml_exp1";;
#open "ml_exp1";;

load_object "prelude";;
#open "prelude";;

load_object "lexer";;
#open "lexer";;

load_object "ml_type";;
#open "ml_type";;

load_object "termes";;
#open "termes";;

load_object "type_synthesis";;
#open "type_synthesis";;

load_object "type_synth";;
#open "type_synth";;

load_object "ml1_parser";;
#open "ml1_parser";;

load_object "type_synth_destr";;
#open "type_synth_destr";;
