#directory "../Util";;
#directory "../Arbres";;

load_object "prelude";;
#open "prelude";;

load_object "orders";;
#open "orders";;

load_object "binary_trees";;
#open "binary_trees";;

load_object "sets";;
#open "sets";;

load_object "games";;
#open "games";;

load_object "games_ane_rouge";;
#open "games_ane_rouge";;

load_object "games_solit";;
#open "games_solit";;

