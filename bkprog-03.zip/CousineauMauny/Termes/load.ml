#directory "../Util";;
#directory "../Eval";;

load_object "prelude";;
#open "prelude";;

load_object "lexer";;
#open "lexer";;

load_object "ml_strict";;
#open "ml_strict";;

load_object "parser_strict";;
#open "parser_strict";;

load_object "gentree";;
#open "gentree";;

load_object "termes";;
#open "termes";;

load_object "ml_ops";;
#open "ml_ops";;

load_object "ml_strict";;
#open "ml_strict";;

load_object "type_synthesis";;
#open "type_synthesis";;

