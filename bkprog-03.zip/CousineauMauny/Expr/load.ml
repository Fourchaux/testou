#directory "../Util";;

load_object "prelude";;

#infix "o";;

#open "prelude";;

load_object "defs";;

#open "defs";;
