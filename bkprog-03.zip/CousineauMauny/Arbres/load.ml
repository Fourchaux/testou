#directory "../Util";;

load_object "prelude";;

#open "prelude";;

#infix "o";;

load_object "orders";;

#open "orders";;

load_object "binary_trees";;

#open "binary_trees";;

load_object "dictionnaries";;

#open "dictionnaries";;

load_object "sets";;

#open "sets";;
