#directory "../Util";;

load_object "ml_exp1";;
#open "ml_exp1";;

load_object "lexer";;
#open "lexer";;

load_object "ml1_parser";;
#open "ml1_parser";;

load_object "code_simulator";;
#open "code_simulator";;

load_object "ml1_compiler";;
#open "ml1_compiler";;
