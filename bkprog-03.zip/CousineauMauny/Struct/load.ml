#directory "../Util";;

include "prelude";;

load_object "lexer";;

include "defs";;

