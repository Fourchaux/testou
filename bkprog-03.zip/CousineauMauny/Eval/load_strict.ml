load_object "ml_ops";;
#open "ml_ops";;

#directory "../Util";;

load_object "lexer";;

load_object "parser_strict";;

load_object "ml_strict";;
#open "ml_strict";;

load_object "eval_strict";;
#open "eval_strict";;
