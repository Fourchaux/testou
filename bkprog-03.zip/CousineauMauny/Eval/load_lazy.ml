load_object "ml_ops";;
#open "ml_ops";;

#directory "../Util";;

load_object "lexer";;

load_object "ml_lazy";;
#open "ml_lazy";;

load_object "parser_lazy";;

load_object "eval_lazy";;
#open "eval_lazy";;

