include "load_strict";;

include "load_lazy";;
