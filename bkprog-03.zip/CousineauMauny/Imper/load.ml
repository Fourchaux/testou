#directory "../Util";;

load_object "prelude";;
#open "prelude";;

load_object "circular_list";;
#open "circular_list";;

load_object "queue";;
#open "queue";;

load_object "double_circular_list";;
#open "double_circular_list";;


